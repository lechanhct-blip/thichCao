// Use an integer for version numbers
version = 1

cloudstream {
    // All of these properties are optional, you can safely remove any of them.
    description = "JAVHDZ"
    authors = listOf("ngoctan,lechanh")

    /**
    * Status int as one of the following:
    * 0: Down
    * 1: Ok
    * 2: Slow
    * 3: Beta-only
    **/
    status = 1 // Will be 3 if unspecified

    tvTypes = listOf("NSFW")
    
    //dong nay de kiem tra thu muc RES

    //requiresResources = true
    language = "vi"

    // Random CC logo I found
    iconUrl = "https://raw.githubusercontent.com/lechanhct-blip/thichCao/builds/logo.jpg"
}
